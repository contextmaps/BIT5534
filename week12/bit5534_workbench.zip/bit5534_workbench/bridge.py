#!/usr/bin/env python3
"""
bridge.py, one course tool in the browser.

BIT 5534 analytics workbench, 2026-11-11. This program starts one of the course
tools (reg_explorer.py, tree_explorer.py, nn_explorer.py, svm_explorer.py or
threshold_explorer.py) with its window hidden, and shows the same controls and the
same tabs in a browser page. Every number, figure and report comes from the tool's
own code, so the browser version and the desktop tool give the same results.

workbench.py starts five of these, one per tool. To start one by hand:

    python bridge.py reg_explorer.py 8001
"""
import sys, os, io, json, gc, time, queue, threading, base64, traceback, importlib.util, tempfile, shutil
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit, unquote

HERE = os.path.dirname(os.path.abspath(__file__))
TOOL_FILE = sys.argv[1] if len(sys.argv) > 1 else 'reg_explorer.py'
PORT = int(sys.argv[2]) if len(sys.argv) > 2 else 8001
TOOL = os.path.splitext(os.path.basename(TOOL_FILE))[0]
WORK = os.path.join(tempfile.gettempdir(), f'bit5534_workbench_{TOOL}_{os.getpid()}')
UPLOADS = os.path.join(WORK, 'uploads')
SAVES = os.path.join(HERE, 'saved_files')
SHORT = TOOL.split('_')[0]
os.makedirs(UPLOADS, exist_ok=True); os.makedirs(SAVES, exist_ok=True)

import tkinter as tk
from tkinter import ttk, filedialog, messagebox

STATE = {'root': None, 'upload': None, 'messages': [], 'files': [], 'pending_save': [], 'version': 0}
ACTIONS = queue.Queue()


# ----------------------------------------------------------------- the tool, hidden
def patch_dialogs():
    def ask_open(*a, **k):
        p = STATE['upload']; STATE['upload'] = None
        return p or ''
    def ask_save(*a, **k):
        name = k.get('initialfile') or ''
        ext = k.get('defaultextension') or ''
        if not name:
            base = {'Save report': f'{TOOL.split("_")[0]}_report'}.get(k.get('title', ''), f'{TOOL.split("_")[0]}_saved')
            name = base + ext
        if ext and not name.lower().endswith(ext.lower()):
            name += ext
        stem, e = os.path.splitext(os.path.basename(name))
        if not stem.lower().startswith(SHORT):
            stem = f'{SHORT}_{stem}'
        name = f'{stem}_{time.strftime("%H%M%S")}{e}'
        path = os.path.join(SAVES, name)
        STATE['pending_save'].append(path)
        return path
    filedialog.askopenfilename = ask_open
    filedialog.asksaveasfilename = ask_save
    def note(kind):
        def f(title=None, message=None, *a, **k):
            STATE['messages'].append(f'{title}: {message}' if title else str(message))
            return True if kind == 'ask' else 'ok'
        return f
    for n in ('showinfo', 'showwarning', 'showerror'):
        setattr(messagebox, n, note('show'))
    for n in ('askyesno', 'askokcancel', 'askquestion', 'askretrycancel', 'askyesnocancel'):
        setattr(messagebox, n, note('ask'))


BINDS = {}


def patch_bind():
    orig = tk.Misc.bind
    def bind(self, sequence=None, func=None, add=None):
        if sequence and func is not None and callable(func):
            BINDS.setdefault((str(self), sequence), []).append(func)
        return orig(self, sequence, func, add)
    tk.Misc.bind = bind


class FakeEvent:
    def __init__(self, w):
        self.widget = w; self.x = self.y = 0; self.keysym = 'Return'; self.char = '\r'; self.delta = 0


def fire(w, sequence):
    fns = BINDS.get((str(w), sequence), [])
    for f in fns:
        f(FakeEvent(w))
    return bool(fns)


def start_tool():
    made = []
    orig_init = tk.Tk.__init__
    def init(self, *a, **k):
        orig_init(self, *a, **k); made.append(self)
    tk.Tk.__init__ = init
    tk.Tk.mainloop = lambda self, n=0: None
    sys.argv = [TOOL_FILE]
    spec = importlib.util.spec_from_file_location(TOOL, os.path.join(HERE, TOOL_FILE))
    mod = importlib.util.module_from_spec(spec)
    sys.modules[TOOL] = mod
    spec.loader.exec_module(mod)
    if hasattr(mod, 'App'):
        app = mod.App(None)
    else:
        mod.main(None)
    root = made[0]
    root.withdraw()
    root.update()
    STATE['root'] = root
    return root


# ----------------------------------------------------------------- reading the window
def figures_by_widget():
    out = {}
    try:
        from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
    except Exception:
        return out
    for o in gc.get_objects():
        try:
            if isinstance(o, FigureCanvasTkAgg):
                out[str(o.get_tk_widget())] = o.figure
        except Exception:
            pass
    return out


def fig_png(fig):
    buf = io.BytesIO()
    try:
        fig.savefig(buf, format='png', dpi=90)
    except Exception as e:
        return ''
    return 'data:image/png;base64,' + base64.b64encode(buf.getvalue()).decode()


def disabled(w):
    try:
        if hasattr(w, 'instate') and w.instate(['disabled']):
            return True
    except Exception:
        pass
    try:
        return str(w.cget('state')) == 'disabled'
    except Exception:
        return False


def var_value(w, opt):
    try:
        v = w.cget(opt)
        return w.getvar(str(v)) if str(v) else None
    except Exception:
        return None


def describe(w, figs):
    cls = w.winfo_class()
    wid = str(w)
    try:
        if cls in ('TLabel', 'Label'):
            t = str(w.cget('text')).strip()
            return {'k': 'label', 't': t} if t else None
        if cls in ('TButton', 'Button'):
            return {'k': 'button', 'id': wid, 't': str(w.cget('text')), 'off': disabled(w)}
        if cls == 'TCombobox':
            return {'k': 'combo', 'id': wid, 'v': w.get(), 'opts': list(w.cget('values') or []), 'off': disabled(w)}
        if cls in ('TEntry', 'Entry'):
            return {'k': 'entry', 'id': wid, 'v': w.get(), 'off': disabled(w)}
        if cls in ('TSpinbox', 'Spinbox'):
            return {'k': 'entry', 'id': wid, 'v': w.get(), 'off': disabled(w)}
        if cls in ('TRadiobutton', 'Radiobutton'):
            on = str(var_value(w, 'variable')) == str(w.cget('value'))
            return {'k': 'radio', 'id': wid, 't': str(w.cget('text')), 'on': on, 'g': str(w.cget('variable')), 'off': disabled(w)}
        if cls in ('TCheckbutton', 'Checkbutton'):
            v = var_value(w, 'variable')
            on = str(v) not in ('0', '', 'False', 'None')
            return {'k': 'check', 'id': wid, 't': str(w.cget('text')), 'on': on, 'off': disabled(w)}
        if cls == 'Listbox':
            return {'k': 'list', 'id': wid, 'items': [str(x) for x in w.get(0, 'end')],
                    'sel': list(w.curselection()), 'multi': str(w.cget('selectmode')) in ('multiple', 'extended')}
        if cls == 'Text':
            return {'k': 'text', 'id': wid, 'v': w.get('1.0', 'end-1c')}
        if cls == 'Treeview':
            cols = list(w.cget('columns'))
            heads = [w.heading(c, 'text') or c for c in cols]
            rows, colors = [], {}
            for iid in w.get_children(''):
                tags = w.item(iid, 'tags') or ()
                bg = ''
                for tg in tags:
                    try:
                        bg = w.tag_configure(tg, 'background') or bg
                    except Exception:
                        pass
                rows.append({'iid': iid, 'v': [str(x) for x in w.item(iid, 'values')], 'bg': str(bg)})
            return {'k': 'table', 'id': wid, 'heads': heads, 'rows': rows, 'sel': list(w.selection())}
        if wid in figs:
            return {'k': 'figure', 'png': fig_png(figs[wid])}
    except Exception:
        return None
    return None


def grid_of(w, figs):
    kids = w.winfo_children()
    if len(kids) < 4 or not all(k.winfo_manager() == 'grid' for k in kids):
        return None
    cells = {}
    for k in kids:
        g = k.grid_info()
        d = describe(k, figs)
        if d is None:
            sub = []
            walk(k, figs, sub)
            d = {'k': 'stack', 'items': sub} if sub else None
        if d is not None:
            cells[(int(g['row']), int(g['column']))] = dict(d, span=int(g.get('columnspan', 1)))
    if not cells:
        return None
    nr = max(r for r, _ in cells) + 1; nc = max(c for _, c in cells) + 1
    if nc > 5:
        # a wide row of label and control pairs reads better as a list in the sidebar
        return {'k': 'stack', 'items': [cells[k] for k in sorted(cells)]}
    return {'k': 'grid', 'rows': [[cells.get((r, c)) for c in range(nc)] for r in range(nr)]}


def walk(w, figs, out):
    for c in w.winfo_children():
        cls = c.winfo_class()
        if cls == 'TNotebook':
            tabs = []
            for tid in c.tabs():
                frame = c.nametowidget(tid)
                inner = []
                d = describe(frame, figs)
                if d: inner.append(d)
                walk(frame, figs, inner)
                tabs.append({'t': c.tab(tid, 'text'), 'items': inner})
            out.append({'k': 'notebook', 'id': str(c), 'tabs': tabs, 'cur': c.index('current') if c.tabs() else 0})
            continue
        if cls in ('TLabelframe', 'Labelframe'):
            inner = []
            g = grid_of(c, figs)
            if g: inner.append(g)
            else: walk(c, figs, inner)
            out.append({'k': 'group', 't': str(c.cget('text')), 'items': inner})
            continue
        d = describe(c, figs)
        if d:
            out.append(d)
            continue
        if str(c) in figs or cls in ('Text', 'Treeview', 'Listbox'):
            continue
        g = grid_of(c, figs)
        if g:
            out.append(g)
        else:
            walk(c, figs, out)


def snapshot():
    root = STATE['root']
    figs = figures_by_widget()
    items = []
    walk(root, figs, items)
    msgs, STATE['messages'] = STATE['messages'], []
    clip = STATE.pop('clip', None)
    return {'title': root.title(), 'items': items, 'messages': msgs, 'clip': clip,
            'files': [os.path.basename(p) for p in STATE['files']]}


# ----------------------------------------------------------------- acting on the window
def settle(seconds=0.4):
    root = STATE['root']
    end = time.time() + seconds
    while time.time() < end:
        root.update()
        time.sleep(0.02)


def act(a):
    root = STATE['root']
    w = root.nametowidget(a['id']) if a.get('id') else None
    k = a['do']
    if k == 'button':
        try:
            root.clipboard_clear(); root.clipboard_append('\x00')
        except Exception:
            pass
        w.invoke()
        try:
            clip = root.clipboard_get()
            if clip and clip != '\x00':
                STATE['clip'] = clip
        except Exception:
            pass
    elif k == 'radio' or k == 'check':
        w.invoke()
    elif k == 'combo':
        w.set(a['v'])
        if not fire(w, '<<ComboboxSelected>>'):
            w.event_generate('<<ComboboxSelected>>')
    elif k == 'entry':
        if w.winfo_class() in ('TSpinbox',):
            w.set(a['v'])
        else:
            w.delete(0, 'end'); w.insert(0, a['v'])
        hit = fire(w, '<Return>') | fire(w, '<KP_Enter>') | fire(w, '<FocusOut>')
        if not hit:
            try:
                w.event_generate('<Return>'); w.event_generate('<FocusOut>')
            except Exception:
                pass
    elif k == 'list':
        w.selection_clear(0, 'end')
        for i in a['sel']:
            w.selection_set(int(i))
        if not fire(w, '<<ListboxSelect>>'):
            w.event_generate('<<ListboxSelect>>')
    elif k == 'table':
        w.selection_set(a['iid']); w.focus(a['iid']); w.see(a['iid'])
        if not fire(w, '<<TreeviewSelect>>'):
            w.event_generate('<<TreeviewSelect>>')
    elif k == 'tab':
        w.select(int(a['i']))
    elif k == 'open':
        STATE['upload'] = a['path']
        btn = find_open_button(root)
        if btn is not None:
            btn.invoke()
    settle()
    for p in list(STATE['pending_save']):
        base = os.path.splitext(p)[0]
        for cand in (p, base + '.txt', base + '.pdf', base + '.csv'):
            if os.path.exists(cand) and cand not in STATE['files']:
                STATE['files'].append(cand)
    STATE['pending_save'] = []


def find_open_button(w):
    for c in w.winfo_children():
        if c.winfo_class() in ('TButton', 'Button') and str(c.cget('text')).lower().startswith('open'):
            return c
        r = find_open_button(c)
        if r is not None:
            return r
    return None


# ----------------------------------------------------------------- the server
PAGE = open(os.path.join(HERE, 'bridge_page.html'), encoding='utf-8').read()


def run_on_tk(fn, *args):
    done = queue.Queue()
    ACTIONS.put((fn, args, done))
    ok, val = done.get(timeout=600)
    if not ok:
        raise RuntimeError(val)
    return val


class Handler(BaseHTTPRequestHandler):
    def send(self, code, body, ctype, extra=None):
        data = body if isinstance(body, bytes) else body.encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        path = unquote(urlsplit(self.path).path)
        try:
            if path == '/':
                self.send(200, PAGE.replace('@@TOOL@@', TOOL), 'text/html; charset=utf-8')
            elif path == '/state':
                self.send(200, json.dumps(run_on_tk(snapshot)), 'application/json')
            elif path.startswith('/file/'):
                name = os.path.basename(path[6:])
                for p in STATE['files']:
                    if os.path.basename(p) == name and os.path.exists(p):
                        ctype = {'.txt': 'text/plain; charset=utf-8', '.pdf': 'application/pdf',
                                 '.csv': 'text/csv; charset=utf-8'}.get(os.path.splitext(name)[1].lower(), 'application/octet-stream')
                        disp = 'inline' if name.lower().endswith('.txt') else f'attachment; filename="{name}"'
                        with open(p, 'rb') as fh:
                            return self.send(200, fh.read(), ctype, {'Content-Disposition': disp})
                self.send(404, 'not found', 'text/plain')
            else:
                self.send(404, 'not found', 'text/plain')
        except Exception as e:
            self.send(500, json.dumps({'error': str(e)}), 'application/json')

    def do_POST(self):
        path = urlsplit(self.path).path
        n = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(n)
        try:
            if path == '/upload':
                name = os.path.basename(unquote(self.headers.get('X-Filename', 'data.csv'))) or 'data.csv'
                dest = os.path.join(UPLOADS, name)
                with open(dest, 'wb') as fh:
                    fh.write(body)
                run_on_tk(act, {'do': 'open', 'path': dest})
            else:
                run_on_tk(act, json.loads(body or b'{}'))
            self.send(200, json.dumps(run_on_tk(snapshot)), 'application/json')
        except Exception as e:
            self.send(400, json.dumps({'error': str(e)}), 'application/json')

    def log_message(self, *a):
        pass


def main():
    patch_dialogs()
    patch_bind()
    root = start_tool()
    server = ThreadingHTTPServer(('127.0.0.1', PORT), Handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    print(f'{TOOL} ready at http://localhost:{PORT}', flush=True)
    while True:
        try:
            fn, args, done = ACTIONS.get(timeout=0.03)
            try:
                done.put((True, fn(*args)))
            except Exception as e:
                traceback.print_exc()
                done.put((False, f'{type(e).__name__}: {e}'))
        except queue.Empty:
            pass
        try:
            root.update()
        except tk.TclError:
            break


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        pass
    finally:
        shutil.rmtree(WORK, ignore_errors=True)
