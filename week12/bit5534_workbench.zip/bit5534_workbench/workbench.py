#!/usr/bin/env python3
"""
workbench.py, the BIT 5534 analytics workbench.

Starts the five course tools in your browser, with a dashboard page that opens each
tool in its own tab and holds your team's agent. Keep this window open while you work.
Close it, or press Ctrl+C in it, to stop everything.

    Windows: double-click workbench.py, or type   python workbench.py
    Mac:     in Terminal, type                     python3 workbench.py

Keep these files together in one folder: workbench.py, workbench_page.html, bridge.py,
bridge_page.html and the five tools (reg_explorer.py, tree_explorer.py, nn_explorer.py,
svm_explorer.py, threshold_explorer.py). Saved reports go to the saved_files folder here.
"""
import os, sys, json, socket, subprocess, threading, time, webbrowser, traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit

HERE = os.path.dirname(os.path.abspath(__file__))
TOOLS = [('reg', 'reg_explorer.py', 'Regression', 'Multiple regression for a number target, logistic regression for a category target.'),
         ('tree', 'tree_explorer.py', 'Decision tree', 'Regression and decision trees, grown split by split.'),
         ('nn', 'nn_explorer.py', 'Neural network', 'A network with one or two hidden layers.'),
         ('svm', 'svm_explorer.py', 'Support vector machine', 'RBF or linear kernel, with a grid search of C and gamma.'),
         ('threshold', 'threshold_explorer.py', 'Threshold', 'Compares saved probability columns: confusion matrix, curves, ROC and lift.')]
# The exact imports each tool makes when it starts. A package can be installed and still fail
# to import (two Pythons on one laptop, or a package built for another numpy), so the
# workbench tries each import itself and reports the real error.
COMMON = ['numpy', 'pandas', 'matplotlib', 'matplotlib.backends.backend_tkagg']
NEEDS = {'reg': COMMON + ['statsmodels.api'],
         'tree': COMMON + ['sklearn.tree'],
         'nn': COMMON + ['scipy.optimize'],
         'svm': COMMON + ['sklearn.svm'],
         'threshold': COMMON}
PIP = {'numpy': 'numpy', 'pandas': 'pandas', 'matplotlib': 'matplotlib', 'statsmodels': 'statsmodels',
       'scipy': 'scipy', 'sklearn': 'scikit-learn'}
PROBLEMS = {}
AGENT_FILE = os.path.join(HERE, 'saved_files', 'agent_link.txt')
CHILDREN, PORTS, STATUS = [], {}, {}


def free_port(start):
    for p in range(start, start + 200):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            s.bind(('127.0.0.1', p)); s.close(); return p
        except OSError:
            s.close()
    raise RuntimeError('No free port found between %d and %d.' % (start, start + 200))


def check_setup():
    missing = [f for f in ['workbench_page.html', 'bridge.py', 'bridge_page.html'] + [t[1] for t in TOOLS]
               if not os.path.exists(os.path.join(HERE, f))]
    if missing:
        raise RuntimeError('These files are missing from the folder ' + HERE + ':\n  ' + '\n  '.join(missing) +
                           '\nDownload them again and keep all of them in one folder.')
    try:
        import tkinter  # noqa
    except Exception:
        raise RuntimeError('This Python has no tkinter. Use the same Python you used for the course tools.')
    import importlib
    failed = {}
    for key, mods in NEEDS.items():
        for m in mods:
            if m in failed:
                PROBLEMS.setdefault(key, []).append(m); continue
            try:
                importlib.import_module(m)
            except Exception as e:
                failed[m] = f'{type(e).__name__}: {e}'
                PROBLEMS.setdefault(key, []).append(m)
    try:
        import openpyxl  # noqa
    except Exception:
        print('Note: openpyxl is not installed, so the tools open .csv files but not .xlsx files.')
    if failed:
        pkgs = sorted({PIP[m.split('.')[0]] for m in failed})
        cmd = f'"{sys.executable}" -m pip install --upgrade ' + ' '.join(pkgs)
        print('\nSome packages did not load in this Python:')
        for m, err in failed.items():
            print(f'  {m}: {err}')
        print('\nClose this window, copy the whole line below into a terminal, press Enter, and start the workbench again.')
        print('It installs into the same Python that runs the workbench:\n')
        print('  ' + cmd + '\n')
        print('If the terminal says the requirement is already satisfied, use this line instead:\n')
        print('  ' + cmd.replace('--upgrade', '--upgrade --force-reinstall') + '\n')
        STATUS['fix'] = cmd
        names = ', '.join(t for k, f, t, _ in TOOLS if k in PROBLEMS)
        print(f'These tools cannot start until then: {names}. The other tools start now.\n')


def start_tools(first):
    port = first
    for key, fname, title, _ in TOOLS:
        port = free_port(port)
        PORTS[key] = port
        if key in PROBLEMS:
            CHILDREN.append(None)
        else:
            # The bridge reads its stdin until the workbench closes, then stops, so no tool
            # keeps running in the background after the black window is closed.
            CHILDREN.append(subprocess.Popen([sys.executable, os.path.join(HERE, 'bridge.py'), fname, str(port)],
                                             cwd=HERE, stdin=subprocess.PIPE))
        port += 1


def alive(port):
    s = socket.socket(); s.settimeout(0.3)
    try:
        s.connect(('127.0.0.1', port)); return True
    except OSError:
        return False
    finally:
        s.close()


class Hub(BaseHTTPRequestHandler):
    def send(self, code, body, ctype):
        data = body.encode('utf-8') if isinstance(body, str) else body
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        path = urlsplit(self.path).path
        if path == '/':
            with open(os.path.join(HERE, 'workbench_page.html'), encoding='utf-8') as fh:
                self.send(200, fh.read(), 'text/html; charset=utf-8')
        elif path == '/status':
            agent = open(AGENT_FILE, encoding='utf-8').read().strip() if os.path.exists(AGENT_FILE) else ''
            saved = sorted(f for f in os.listdir(os.path.join(HERE, 'saved_files')) if f != 'agent_link.txt')
            tools = [{'key': k, 'title': t, 'about': a, 'port': PORTS[k], 'ready': alive(PORTS[k]),
                      'problem': ', '.join(PROBLEMS.get(k, []))} for k, _, t, a in TOOLS]
            self.send(200, json.dumps({'tools': tools, 'agent': agent, 'folder': os.path.join(HERE, 'saved_files'),
                                       'saved': saved, 'fix': STATUS.get('fix', '')}), 'application/json')
        else:
            self.send(404, 'not found', 'text/plain')

    def do_POST(self):
        if urlsplit(self.path).path == '/agent':
            n = int(self.headers.get('Content-Length', 0))
            link = json.loads(self.rfile.read(n) or b'{}').get('link', '').strip()
            with open(AGENT_FILE, 'w', encoding='utf-8') as fh:
                fh.write(link)
            self.send(200, '{}', 'application/json')
        else:
            self.send(404, 'not found', 'text/plain')

    def log_message(self, *a):
        pass


def stop_children():
    for c in CHILDREN:
        try:
            if c: c.terminate()
        except Exception:
            pass


def main():
    print('BIT 5534 analytics workbench')
    print('Checking the folder and the Python packages...')
    check_setup()
    os.makedirs(os.path.join(HERE, 'saved_files'), exist_ok=True)
    hub_port = free_port(8000)
    start_tools(hub_port + 1)
    server = ThreadingHTTPServer(('127.0.0.1', hub_port), Hub)
    url = f'http://localhost:{hub_port}'
    threading.Thread(target=server.serve_forever, daemon=True).start()
    print(f'\nThe workbench is at {url}')
    print('Your browser opens it in a moment. If it does not, copy the address into your browser.')
    print('Keep this window open while you work. Press Ctrl+C here, or close this window, to stop.\n')
    time.sleep(1.5)
    try:
        webbrowser.open(url)
    except Exception:
        pass
    while True:
        time.sleep(1)
        for (key, fname, _, _), c in zip(TOOLS, CHILDREN):
            if c is not None and c.poll() is not None and not getattr(c, 'reported', False):
                c.reported = True
                print(f'\n{fname} stopped. The lines above it show why. The other tools keep running.')


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print('\nStopping the workbench.')
    except Exception as e:
        print('\nThe workbench could not start.\n')
        print(e if isinstance(e, RuntimeError) else traceback.format_exc())
        try:
            input('\nPress Enter to close this window.')
        except Exception:
            pass
    finally:
        stop_children()
