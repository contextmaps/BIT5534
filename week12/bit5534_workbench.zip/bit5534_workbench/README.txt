BIT 5534 analytics workbench

The five course tools in your browser, with your team's agent beside them.

To start
  Windows: double-click workbench.py. If the file opens in an editor instead, open a
           terminal in this folder (click the address bar of the folder window, type cmd,
           press Enter) and type:   python workbench.py
  Mac:     open Terminal, type cd and a space, drag this folder into the Terminal window,
           press Return, then type:   python3 workbench.py

Keep this folder in your home folder or Documents, not on the Desktop and not in a folder
that OneDrive or iCloud syncs.

A window opens and stays open while you work. Your browser opens the workbench. If it does
not, copy the address from the window into your browser. To stop, close the window or press
Ctrl+C in it. If something goes wrong, the window stays open and says what happened.

Keep every file in this folder together. Saved reports go to the saved_files folder here.
Lumenvale's title file and a copy with saved probabilities are included for practice.
