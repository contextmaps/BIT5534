BIT 5534 analytics workbench

The five course tools in your browser, with your team's agent beside them.

To start
  Windows: double-click workbench.py. If the file opens in an editor instead, open a
           terminal in this folder (click the address bar of the folder window, type cmd,
           press Enter) and type:   python workbench.py
  Mac:     open Terminal, type cd and a space, drag this folder into the Terminal window,
           press Return, then type:   python3 workbench.py

Keep this folder in your home folder or Documents, not on the Desktop and not in a folder
that OneDrive or iCloud syncs.

A window opens and stays open while you work. Your browser opens the workbench. If it does
not, copy the address from the window into your browser. To stop, close the window or press
Ctrl+C in it. If something goes wrong, the window stays open and says what happened.

Keep every file in this folder together. Saved reports go to the saved_files folder here.
Lumenvale's title file and a copy with saved probabilities are included for practice.

If a tool does not start
  The window lists each package that did not load, with the error, and prints one line
  to copy into a terminal. That line names the Python that runs the workbench, so the
  install goes to the right place. Close the workbench, run the line, and start the
  workbench again. If the terminal says "Requirement already satisfied", run the second
  line the window prints, which reinstalls the package. The other tools keep working in
  the meantime, and the desktop tools save the same reports.

Version 3, 2026-11-12.
